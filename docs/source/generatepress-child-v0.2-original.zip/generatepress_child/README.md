# GeneratePress Child – Projektpaket

## Enthalten

- `style.css`
  - `--gb-container-width: 1280px`
  - Fluid-Typografie `--fs-h1` bis `--fs-h6`
  - `--fs-p`
  - `fs-*`-Utility-Klassen
  - GenerateBlocks-Button-Typografie

- `functions.php`
  - lädt `style.css` mit `add_editor_style()` in den Block-Editor
  - behält die GenerateBlocks-Template-Vorschaubildspalte bei
  - gibt die Admin-CSS-Regel nur einmal pro Listenansicht aus

## Wichtig für Backend-/Frontend-Parität

Dieses Child Theme stellt dieselben globalen Typografie- und Container-Tokens
im Frontend und im Editor bereit.

Die Geometrie eines einzelnen GenerateBlocks-Blocks muss trotzdem
containerrelativ gebaut sein.

Für neue Sections:

```css
/* Outer section */
width: 100%;
max-width: 100%;

/* Direct inner container */
width: 100%;
max-width: var(--gb-container-width, 1280px);
margin-left: auto;
margin-right: auto;
```

Interne dekorative Shapes sollten sich an ihrem lokalen Komponentencontainer
orientieren (z. B. Prozentwerte innerhalb eines `position:relative`-Parents),
nicht an `vw`/`vh`, wenn Backend und Frontend bei derselben Komponentenbreite
gleich aussehen sollen.

## GeneratePress

GeneratePress lädt das Child-Theme-`style.css` im Frontend automatisch.
Das Parent-Stylesheet daher weder per `@import` noch manuell per
`wp_enqueue_style()` einbinden.

Für Seiten mit echten Full-Width-GenerateBlocks-Sections sollte der
GeneratePress Content Container entsprechend auf **Full Width** eingestellt
sein, damit das Theme die Section nicht zusätzlich einschränkt.

## Installation

1. GeneratePress als Parent Theme installiert lassen.
2. ZIP über **Design → Themes → Hinzufügen → Theme hochladen** installieren.
3. Child Theme aktivieren.
4. Bestehende GeneratePress-Customizer-Einstellungen kontrollieren.
5. Gutenberg und Frontend bei derselben effektiven Blockbreite vergleichen.

Editor-Seitenleisten, Listenansicht und WordPress-Toolbar gehören nicht zur
Komponentengeometrie und verkleinern die verfügbare Editorfläche.

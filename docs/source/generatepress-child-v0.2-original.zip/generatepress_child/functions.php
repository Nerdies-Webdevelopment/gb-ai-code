<?php
/**
 * GeneratePress Child Theme
 *
 * Project-specific PHP belongs here.
 * Do not copy the GeneratePress parent theme functions.php into this file.
 *
 * @package GeneratePress_Child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Load the child-theme stylesheet in the WordPress block editor.
 *
 * GeneratePress loads the child theme style.css on the frontend itself,
 * so no wp_enqueue_scripts callback is required for the frontend.
 *
 * WordPress scopes editor styles for the block editor, which keeps the
 * same typography variables and utility classes available in both places.
 */
function generatepress_child_editor_styles() {
	add_theme_support( 'editor-styles' );
	add_editor_style( 'style.css' );
}
add_action( 'after_setup_theme', 'generatepress_child_editor_styles' );


/**
 * Add a featured-image column to GenerateBlocks templates.
 *
 * @param array $columns Existing list-table columns.
 * @return array
 */
function tct_featured_image_column( $columns ) {
	return array_slice( $columns, 0, 1, true )
		+ array(
			'featured_image' => 'Featured Image',
		)
		+ array_slice( $columns, 1, null, true );
}
add_filter(
	'manage_gblocks_templates_posts_columns',
	'tct_featured_image_column'
);


/**
 * Render the featured-image column.
 *
 * @param string $column_name Current column name.
 * @param int    $post_id     Current post ID.
 */
function tct_render_the_column( $column_name, $post_id ) {
	if ( 'featured_image' !== $column_name ) {
		return;
	}

	if ( ! has_post_thumbnail( $post_id ) ) {
		return;
	}

	$thumbnail_id = get_post_thumbnail_id( $post_id );
	$url          = wp_get_attachment_image_url( $thumbnail_id, 'medium' );

	if ( ! $url ) {
		return;
	}
	?>
	<img
		data-id="<?php echo esc_attr( $thumbnail_id ); ?>"
		src="<?php echo esc_url( $url ); ?>"
		alt=""
	/>
	<?php
}
add_action(
	'manage_gblocks_templates_posts_custom_column',
	'tct_render_the_column',
	10,
	2
);


/**
 * Admin-only styling for the GenerateBlocks template thumbnail column.
 *
 * Printed once per list-table screen instead of once per table row.
 */
function tct_featured_image_column_styles() {
	$screen = get_current_screen();

	if ( ! $screen || 'gblocks_templates' !== $screen->post_type ) {
		return;
	}
	?>
	<style>
		.post-type-gblocks_templates #featured_image {
			width: 150px;
		}

		.post-type-gblocks_templates
		td.featured_image.column-featured_image img {
			display: block;
			max-width: 100%;
			height: auto;
		}
	</style>
	<?php
}
add_action( 'admin_head-edit.php', 'tct_featured_image_column_styles' );
